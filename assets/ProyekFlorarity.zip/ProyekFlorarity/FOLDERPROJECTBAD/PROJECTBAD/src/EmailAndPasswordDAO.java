import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmailAndPasswordDAO {
    private Connect dc;

    public EmailAndPasswordDAO() {
        this.dc = Connect.getInstance(); 
    }

    // Validasi login user berdasarkan email dan password
    public boolean validateLogin(String email, String password) {
        String sql = "SELECT 1 FROM MsUser WHERE UserEmail = ? AND UserPassword = ?";
        
        try (PreparedStatement pstmt = dc.prepareStatement(sql)) {
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  
    public String getUserRole(String email) {
        String sql = "SELECT UserRole FROM MsUser WHERE UserEmail = ?";
        
        try (PreparedStatement pstmt = dc.prepareStatement(sql)) {
            pstmt.setString(1, email);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("UserRole"); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; 
    }

   
    public boolean isUniqueEmail(String email) {
        String sql = "SELECT 1 FROM MsUser WHERE UserEmail = ?";
        
        try (PreparedStatement pstmt = dc.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            return !rs.next(); 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
