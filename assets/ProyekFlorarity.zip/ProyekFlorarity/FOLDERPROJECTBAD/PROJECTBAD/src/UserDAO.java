import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    private Connection connection;

    public UserDAO(Connection connection) {
        if (connection == null) {
            throw new IllegalArgumentException("Connection cannot be null");
        }
        this.connection = connection;
    }

    // Fungsi untuk memvalidasi login berdasarkan email dan password
    public boolean validateLogin(String userEmail, String userPassword) {
        String query = "SELECT * FROM MsUser WHERE UserEmail = ? AND UserPassword = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userEmail);
            stmt.setString(2, userPassword);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; 
        }
    }
    
    
    
    public String getUserRole(String userEmail) {
        String query = "SELECT UserRole FROM MsUser WHERE UserEmail = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userEmail);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("UserRole"); 
                } else {
                    return null; 
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public String getUserNameByID(String userID) {
        String query = "SELECT UserName FROM MsUser WHERE UserID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("UserName"); 
                } else {
                    return null; 
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean registerUser(String username, String password, String email, String phoneNumber, String address) {
        String selectQuery = "SELECT UserID FROM MsUser ORDER BY CAST(SUBSTRING(UserID, 3) AS UNSIGNED) DESC LIMIT 1";
        String insertQuery = "INSERT INTO MsUser (UserID, UserName, UserPassword, UserEmail, UserPhonenumber, UserAddress, UserRole) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (
            PreparedStatement selectStmt = connection.prepareStatement(selectQuery);
            PreparedStatement insertStmt = connection.prepareStatement(insertQuery)
        ) {
            // Dapatkan UserID terakhir
            String lastUserID = null;
            try (ResultSet rs = selectStmt.executeQuery()) {
                if (rs.next()) {
                    lastUserID = rs.getString("UserID");
                }
            }

            // Hitung UserID baru
            String newUserID;
            if (lastUserID == null) {
                newUserID = "US001"; // Tabel kosong, mulai dari US001
            } else {
                int newIDNumber = Integer.parseInt(lastUserID.substring(2)) + 1; // Ekstrak angka dan tambahkan 1
                newUserID = String.format("US%03d", newIDNumber); // Format sebagai USXXX (3 digit angka)
            }

            // Siapkan query untuk menyisipkan data
            insertStmt.setString(1, newUserID);
            insertStmt.setString(2, username);
            insertStmt.setString(3, password);
            insertStmt.setString(4, email);
            insertStmt.setString(5, phoneNumber);
            insertStmt.setString(6, address);
            insertStmt.setString(7, "Customer"); // Default UserRole adalah "Customer"

            // Eksekusi query
            int rowsInserted = insertStmt.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


}
