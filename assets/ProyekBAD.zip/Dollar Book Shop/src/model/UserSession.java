package model;

public class UserSession {
    private static UserSession instance;
    private String email;

    public static UserSession getInstance(){
        if(instance == null){
            instance = new UserSession();}
        return instance;}

    public void setEmail(String email){
        this.email = email;}

    public String getEmail(){
        return email;}}