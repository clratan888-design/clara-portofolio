package model;

import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import util.Connect;

import java.sql.*;

public class Login {
    public Login(Stage primaryStage) {
        Label loginLbl = new Label("Login");
        loginLbl.setStyle("-fx-font-size: 48px; -fx-font-weight: bold;");

        Label emailLbl = new Label("Email:");
        emailLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        TextField emailTf = new TextField();
        emailTf.setPromptText("Email Address");
        emailTf.setMinHeight(30);
        emailTf.setMinWidth(300);

        VBox emailLayout = new VBox(5, emailLbl, emailTf);
        emailLayout.setAlignment(Pos.CENTER_LEFT);

        Label passLbl = new Label("Password:");
        passLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        PasswordField passField = new PasswordField();
        passField.setPromptText("Password");
        passField.setMinHeight(30);
        passField.setMinWidth(300);

        VBox passwordLayout = new VBox(5, passLbl, passField);
        passwordLayout.setAlignment(Pos.CENTER_LEFT);

        Button loginBtn = new Button("Sign In");
        loginBtn.setStyle("-fx-background-color: #00CED1");
        loginBtn.setMinHeight(30);
        loginBtn.setMinWidth(300);
        loginBtn.setOnAction(e->{
            if(emailTf.getText().isEmpty() || passField.getText().isEmpty()){
                showWarning("Please fill in all fields!");}

            if(!emailTf.getText().contains("@")){
                showWarning("Invalid credentials!");}
            else{
                try{
                    if(Connect.validateLogin(emailTf.getText(), passField.getText())){
                        String userRole = Connect.getURole(emailTf.getText(), passField.getText());
                        UserSession.getInstance().setEmail(emailTf.getText());
                        if(userRole != null){
                            if(userRole.equals("admin")){
                                new AdminHome(primaryStage);}
                            else if(userRole.equals("user")){
                                new UserHome(primaryStage);}}
                        else{
                            showWarning("Invalid credentials!");}
                    }
                    else{
                        showWarning("Invalid credentials!");}
                }catch(SQLException ex){
                    ex.printStackTrace();}}});

        Hyperlink signUpLink = new Hyperlink("Don't have an account? Register here!");
        signUpLink.setVisited(false);
        signUpLink.setOnAction(e -> new Register(primaryStage));

        VBox loginLayout = new VBox(10, emailLayout, passwordLayout, loginBtn, signUpLink);
        loginLayout.setAlignment(Pos.CENTER);

        HBox center = new HBox(loginLayout);
        center.setAlignment(Pos.CENTER);

        VBox formLayout = new VBox(10,loginLbl, center);
        formLayout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(formLayout, 1366, 768);
        primaryStage.setTitle("Dollar Book Shop");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showWarning(String message){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Warning");
        alert.setContentText(message);
        alert.showAndWait();}
}