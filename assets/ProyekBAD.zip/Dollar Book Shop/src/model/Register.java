package model;

import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import util.Connect;

import java.sql.*;
import java.time.*;

public class Register {
    public Register(Stage primaryStage) {
        Label registerLbl = new Label("Register");
        registerLbl.setStyle("-fx-font-size: 48px; -fx-font-weight: bold;");

        Label emailLbl = new Label("Email");
        emailLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        TextField emailTf = new TextField();
        emailTf.setPromptText("Email Address");
        emailTf.setMinHeight(30);
        emailTf.setMinWidth(300);

        VBox emailLayout = new VBox(5, emailLbl, emailTf);
        emailLayout.setAlignment(Pos.CENTER_LEFT);

        Label usernameLbl = new Label("Username");
        usernameLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        TextField usernameTf = new TextField();
        usernameTf.setPromptText("Username");
        usernameTf.setMinHeight(30);
        usernameTf.setMinWidth(300);

        VBox usernameLayout = new VBox(5, usernameLbl, usernameTf);
        usernameLayout.setAlignment(Pos.CENTER_LEFT);

        Label passwordLbl = new Label("Password");
        passwordLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        PasswordField passField = new PasswordField();
        passField.setPromptText("Password");
        passField.setMinHeight(30);
        passField.setMinWidth(300);

        VBox passwordLayout = new VBox(5, passwordLbl, passField);
        passwordLayout.setAlignment(Pos.CENTER_LEFT);

        Label confirmPasswordLbl = new Label("Confirm Password");
        confirmPasswordLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");
        confirmPasswordField.setMinHeight(30);
        confirmPasswordField.setMinWidth(300);

        VBox confirmPasswordLayout = new VBox(5, confirmPasswordLbl, confirmPasswordField);
        confirmPasswordLayout.setAlignment(Pos.CENTER_LEFT);

        Label dobLbl = new Label("Date of Birth");
        dobLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        DatePicker dobField = new DatePicker();
        dobField.maxWidth(100);
        dobField.setMinHeight(30);

        VBox dobLayout = new VBox(5, dobLbl, dobField);
        dobLayout.setAlignment(Pos.CENTER_LEFT);

        Button signUpBtn = new Button("Sign Up");
        signUpBtn.setStyle("-fx-background-color: #00CED1");
        signUpBtn.setMinHeight(30);
        signUpBtn.setMinWidth(300);
        signUpBtn.setOnAction(e -> {
            String email = emailTf.getText();
            String username = usernameTf.getText();
            String password = passField.getText();
            String confirmPassword = confirmPasswordField.getText();
            String dob = dobField.getValue().toString();

            if(email.isEmpty() || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || dob.isEmpty()){
                showWarning("All fields must be filled!");}
            else if(!email.contains("@")){
                showWarning("Email must contain @");}
            else if(!password.equals(confirmPassword)){
                showWarning("Passwords do not match!");}
            else if(password.length() < 8){
                showWarning("Password must be at least 8 characters long!");}
            else if(username.length()<5){
                showWarning("Username must be at least 5 characters long!");}
            else if(!alphanumericval(password)){
                showWarning("Password must contain both letters and numbers! (Alphanumeric)");}
            else if(Period.between(dobField.getValue(), LocalDate.now()).getYears()<18){
                showWarning("You must be at least 18 years old to register!");}
            else{
                try{
                    if(Connect.checkEmail(email) && Connect.checkUsername(username)){
                        showWarning("Email / Username already registered!");}
                    else{
                        Connect.addUser(email, password, username, dob);
                        showSuccess("Account created successfully!");
                        new Login(primaryStage);
                    }}
                catch(SQLException ex){
                    ex.printStackTrace();}}});

        Hyperlink loginLink = new Hyperlink("Already have an account? Login here!");
        loginLink.setVisited(false);
        loginLink.setOnAction(e -> new Login(primaryStage));

        VBox registerLayout = new VBox(10, emailLayout, usernameLayout, passwordLayout, confirmPasswordLayout, dobLayout, signUpBtn, loginLink);
        registerLayout.setAlignment(Pos.CENTER);

        HBox center = new HBox(registerLayout);
        center.setAlignment(Pos.CENTER);

        VBox formLayout = new VBox(10, registerLbl, center);
        formLayout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(formLayout, 1366, 768);
        primaryStage.setTitle("Dollar Book Shop");
        primaryStage.setScene(scene);
        primaryStage.show();}

    private void showWarning(String message){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Warning");
        alert.setContentText(message);
        alert.showAndWait();}

    private void showSuccess(String message){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Success");
        alert.setContentText(message);
        alert.showAndWait();}

    private boolean alphanumericval(String name){
        boolean isnum = false,islet=false;
        for(int i = 0; i<name.length();i++){
            for(char c : name.toCharArray()){
                if(Character.isLetter(c)){
                    islet = true;}
                else if(Character.isDigit(c)){
                    isnum = true;}}}
        return islet&&isnum;}

}