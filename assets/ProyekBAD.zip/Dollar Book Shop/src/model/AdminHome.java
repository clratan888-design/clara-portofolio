package model;

import javafx.collections.ObservableList;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import util.Connect;

import java.sql.*;

public class AdminHome {
    private TableView<Books> booksTable;

    public AdminHome(Stage primaryStage) {
        MenuBar mb = MenuBar.createMenuBar(primaryStage, "AdminHome");
        Label welcomeLbl = new Label("Welcome Back, Admin");
        welcomeLbl.setStyle("-fx-font-size: 48px; -fx-font-weight: bold;");

        booksTable = createTable();
        booksTable.setPrefHeight(500);
        booksTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(booksTable, Priority.ALWAYS);

        VBox productLayout = new VBox(5, welcomeLbl, booksTable);
        productLayout.setAlignment(Pos.CENTER_LEFT);
        productLayout.setPadding(new Insets(10));

        Label nameLbl = new Label("Name");
        TextField nameTf = new TextField();
        nameTf.setPromptText("Name");
        nameTf.setMaxWidth(200);

        Label genreLbl = new Label("Genre");
        TextField genreTf = new TextField();
        genreTf.setPromptText("Genre");
        genreTf.setMaxWidth(200);

        Label stockLbl = new Label("Stock");
        Spinner<Integer> stockSpinner = new Spinner<>(0, 100, 0);
        stockSpinner.setEditable(true);

        Label priceLbl = new Label("Price");
        TextField priceTf = new TextField();
        priceTf.setPromptText("Price");
        priceTf.setMaxWidth(200);

        Button deleteBtn = new Button("Delete");
        deleteBtn.setMinWidth(20);
        deleteBtn.setOnAction(e ->{
            Books selectedBook = booksTable.getSelectionModel().getSelectedItem();
            if(selectedBook != null){
                try{
                    Connect.deleteBook(selectedBook.getId());
                    booksTable.setItems(Connect.getBooks());
                    booksTable.refresh();
                }catch(SQLException ex){
                    throw new RuntimeException(ex);}
            }else{
                showWarning("You need to select one product");}});


        Button addBtn = new Button("Add");
        addBtn.setMinWidth(20);
        addBtn.setOnAction(e -> {
            if (nameTf.getText().isEmpty() || genreTf.getText().isEmpty() ||(stockSpinner.getValue().equals(0)) || priceTf.getText().isEmpty()) {
                showWarning("Please fill in all fields!");
            } else {
                try {
                    int pricing = Integer.parseInt(priceTf.getText());
                    if (pricing < 0) {
                        showWarning("Price must be positive!");
                        return;
                    }
                    Connect.addBook(nameTf.getText(), genreTf.getText(), stockSpinner.getValue(), pricing);
                    booksTable.setItems(Connect.getBooks());
                    booksTable.refresh();
                } catch (NumberFormatException ex) {
                    showWarning("Price must be a valid number!");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        Button updateBtn = new Button("Update");
        updateBtn.setMinWidth(20);
        updateBtn.setOnAction(e ->{
            Books selectedBook = booksTable.getSelectionModel().getSelectedItem();
            if(nameTf.getText().isEmpty() || genreTf.getText().isEmpty() || priceTf.getText().isEmpty()){
                showWarning("Please fill in all fields!");return;}

            if(selectedBook != null){
                try {
                    Connect.updateBook(selectedBook.getId(), nameTf.getText(), genreTf.getText(), stockSpinner.getValue(), Integer.parseInt(priceTf.getText()));
                    booksTable.setItems(Connect.getBooks());
                    booksTable.refresh();
                }catch (NumberFormatException ex){
                    showWarning("Price must be numbers!");
                }catch(SQLException ex){
                    throw new RuntimeException(ex);}
            }else{
                showWarning("You need to select one product");}});

        HBox buttons = new HBox(10, deleteBtn, addBtn, updateBtn);
        buttons.setAlignment(Pos.CENTER);

        VBox fields = new VBox(5, nameLbl, nameTf, genreLbl, genreTf, stockLbl, stockSpinner, priceLbl, priceTf, buttons);
        fields.setAlignment(Pos.CENTER_LEFT);

        HBox centredFields = new HBox(fields);
        centredFields.setAlignment(Pos.CENTER);

        VBox layout = new VBox(5, productLayout, centredFields);
        layout.setAlignment(Pos.CENTER);

        VBox finalLayout = new VBox(10, mb, welcomeLbl, layout);

        try{
            ObservableList<Books> books = Connect.getBooks();
            booksTable.setItems(books);
        }catch(SQLException e){
            e.printStackTrace();}

        booksTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                nameTf.setText(newSelection.getName());
                genreTf.setText(newSelection.getGenre());
                stockSpinner.getValueFactory().setValue(newSelection.getStock());
                priceTf.setText(String.valueOf(newSelection.getPrice()));
            }});

        Scene scene = new Scene(finalLayout, 1366, 768);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Dollar Book Shop");
        primaryStage.show();}

    private TableView<Books> createTable(){
        TableView<Books> table = new TableView<>();
        TableColumn<Books, String> IdColumn = new TableColumn<>("Id");
        IdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Books, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Books, String> genreColumn = new TableColumn<>("Genre");
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));

        TableColumn<Books, Integer> stockColumn = new TableColumn<>("Stock");
        stockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));

        TableColumn<Books, Integer> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        table.getColumns().addAll(IdColumn, nameColumn, genreColumn, stockColumn, priceColumn);

        for (TableColumn<?, ?> column : table.getColumns()) {
            column.setPrefWidth(150);}
        return table;}

    private void showWarning(String message){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Warning");
        alert.setContentText(message);
        alert.showAndWait();}
}