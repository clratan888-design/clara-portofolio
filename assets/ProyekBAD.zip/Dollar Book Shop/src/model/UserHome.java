package model;

import javafx.collections.ObservableList;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;
import util.Connect;

import java.sql.*;

public class UserHome {
    private String email = UserSession.getInstance().getEmail();
    private String username = Connect.getUsername(email);
    private TableView<Books> booksTable;
    private StackPane sp;

    Window window = new Window();
    public UserHome(Stage primaryStage) throws SQLException {
        MenuBar mb = MenuBar.createMenuBar(primaryStage, "UserHome");
        Label welcomeLbl = new Label("Hello, " + username);
        welcomeLbl.setStyle("-fx-font-size: 48px; -fx-font-weight: bold;");

        booksTable = createTable();
        booksTable.setPrefHeight(900);
        booksTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(booksTable, Priority.ALWAYS);

        Button addToCart = new Button("Add to Cart");
        addToCart.setMinHeight(75);
        addToCart.setMinWidth(300);
        addToCart.setStyle("-fx-background-color: #808080; -fx-text-fill: white");
        addToCart.setOnAction(e -> {
            Books selectedBook = booksTable.getSelectionModel().getSelectedItem();
            if (selectedBook != null) {
                try {
                    addtoCart(selectedBook.getName(), selectedBook.getGenre(), selectedBook.getPrice());
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            } else {
                showWarning("You need to select one product");
            }
        });

        VBox productLayout = new VBox(5, welcomeLbl, booksTable);
        productLayout.setAlignment(Pos.CENTER_LEFT);
        productLayout.setPadding(new Insets(10));

        VBox buttonLayout = new VBox(5, productLayout, addToCart);
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.setPadding(new Insets(10));

        VBox finalLayout = new VBox(10, mb, buttonLayout);
        finalLayout.setAlignment(Pos.TOP_CENTER);
        try{
            ObservableList<Books> books = Connect.getBooks();
            booksTable.setItems(books);
        }catch(SQLException e){
            e.printStackTrace();}

        sp = new StackPane();
        sp.getChildren().add(finalLayout);
        Scene scene = new Scene(sp, 1366, 768);
        primaryStage.setTitle("Dollar Book Shop");
        primaryStage.setScene(scene);
        primaryStage.show();}

    private TableView<Books> createTable() {
        TableView<Books> table = new TableView<>();
        TableColumn<Books, String> IdColumn = new TableColumn<>("Id");
        IdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Books, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Books, String> genreColumn = new TableColumn<>("Genre");
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));

        TableColumn<Books, Integer> stockColumn = new TableColumn<>("Stock");
        stockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));

        TableColumn<Books, Integer> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        table.getColumns().addAll(IdColumn, nameColumn, genreColumn, stockColumn, priceColumn);

        for (TableColumn<?, ?> column : table.getColumns()) {
            column.setPrefWidth(150);
        }
        return table;
    }

    private void addtoCart(String name, String genre, int price) throws SQLException {
        int stock = Connect.getStock(name);
        int curQuant = Connect.getCartQuantity(email, name);

        Window popUp = new Window("Add to Cart");
        popUp.getLeftIcons().clear();
        popUp.setMaxSize(701, 440);

        Label nameLabel = new Label("Name: " + name);
        nameLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        Label genreLabel = new Label("Genre: " + genre);
        Label priceLabel = new Label("Price: " + price);

        Spinner<Integer> quantity = new Spinner<>(0, stock, curQuant);
        quantity.setPrefSize(300, 30);
        quantity.setEditable(true);

        Button add = new Button("Add");
        add.setPrefSize(60, 30);
        add.setOnAction(e -> {
            int qty = quantity.getValue();
            if(qty>0){
                try{
                    if(curQuant == 0){
                        Connect.addtoCart(email, name, qty);
                        showSuccess("Product added successfully!");}
                    else{
                        Connect.updateCart(email, name, qty);
                        showSuccess("Product updated successfully!");}
                    popUp.close();
                }catch(SQLException ex){
                    ex.printStackTrace();}}
            else{
                showWarning("Quantity must be more than 0");}});

        VBox layout = new VBox(5, nameLabel, genreLabel, priceLabel, quantity, add);
        layout.setAlignment(Pos.TOP_LEFT);
        layout.setPadding(new Insets(10));
        
        popUp.getContentPane().getChildren().add(layout);
        sp.getChildren().add(popUp);

        popUp.toFront();
    }


    private void showWarning(String message){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Warning");
        alert.setContentText(message);
        alert.showAndWait();}

    private void showSuccess(String message){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Success");
        alert.setContentText(message);
        alert.showAndWait();}
}